import csv

col_names = ['calories','label']
unique_ingradient = []
ingradients_index = [0] * 14412

with open('unique_ingradient.csv', mode = 'r') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')

    for row in csv_reader:
        unique_ingradient = row
        col_names.extend(unique_ingradient)
        break

    print(len(col_names))

with open('preprosessed.csv', encoding='utf-8', mode = 'r') as csv_file1:
    csv_reader1 = csv.reader(csv_file1, delimiter=',')
    line_count = 0

    with open('final.csv', mode='w') as preprosessed_file:
        preprosessed_writer = csv.writer(preprosessed_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)

        for row in csv_reader1:
            if line_count == 0:
                preprosessed_writer.writerow(col_names)
                #print(f'Column names are {", ".join(row)}')
                line_count += 1
            else:
                if len(row) > 0:
                    ingradients_index = [0] * 14412
                    contents = [row[0], row[1]]
                    for i in row[2].replace("[", "").replace("]", "").replace("'", "").replace('""', '').split(", "):
                        ingradients_index[unique_ingradient.index(i)] = 1
                    print(ingradients_index)
                    contents.extend(ingradients_index)
                    preprosessed_writer.writerow(contents)
                    line_count += 1
