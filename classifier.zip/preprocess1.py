import csv

with open('RAW_recipes.csv', encoding='utf-8', mode = 'r') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    line_count = 0
    cals = []

    with open('preprosessed.csv', mode='w') as preprosessed_file:
        preprosessed_writer = csv.writer(preprosessed_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)

        for row in csv_reader:
            if line_count == 0:
                preprosessed_writer.writerow(['calories','calorie level','ingradients'])
                #print(f'Column names are {", ".join(row)}')
                line_count += 1
            else:
                if float(row[7].split(",")[0].replace("[", "")) < 1500 and float(row[7].split(",")[0].replace("[", "")) > 50 and "[" in row[11]:
                    if float(row[7].split(",")[0].replace("[", "")) > 850:
                        preprosessed_writer.writerow([row[7].split(",")[0].replace("[", ""), "high", row[11]])
                    elif float(row[7].split(",")[0].replace("[", "")) < 250:
                        preprosessed_writer.writerow([row[7].split(",")[0].replace("[", ""), "low", row[11]])
                    else:
                        preprosessed_writer.writerow([row[7].split(",")[0].replace("[", ""), "moderate", row[11]])
                line_count += 1
        print(f'Processed {line_count} lines.')
