import csv

with open('preprosessed.csv', mode = 'r') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    line_count = 0
    all_in = []

    for row in csv_reader:
        if len(row)>0:
            if line_count == 0:
                line_count += 1
            else:
                all_in.extend(row[2].replace("[", "").replace("]", "").replace("'", "").split(", "))
                line_count += 1

    unique_ingradient = list(set(all_in))

    with open('unique_ingradient.csv', mode='w') as preprosessed_file:
        preprosessed_writer = csv.writer(preprosessed_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
        preprosessed_writer.writerow(unique_ingradient)

    print(f'Processed {line_count} lines.')
    print(len(unique_ingradient))
